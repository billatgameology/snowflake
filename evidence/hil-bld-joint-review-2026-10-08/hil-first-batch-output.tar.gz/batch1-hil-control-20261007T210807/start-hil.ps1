$ErrorActionPreference = 'Stop'
$hilRoot = 'C:\Users\biao3\.codex\worktrees\hil-first-batch\snowflake'
$hilNode = 'C:\Users\biao3\AppData\Local\Programs\nodejs\node-v24.13.1-win-x64\node.exe'
$hilEntry = Join-Path $hilRoot 'runner\src\hil-bld-batch-main.ts'
$hilProbe = Join-Path $hilRoot 'out\batch1-hil-probe'
$hilCampaign = Join-Path $hilRoot 'out\batch1-hil'
$hilControl = $PSScriptRoot
Set-Location -LiteralPath $hilRoot
try {
  @{ phase='probe'; startedUtc=(Get-Date).ToUniversalTime().ToString('o'); wrapperPid=$PID } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $hilControl 'state.json') -Encoding UTF8
  $hilProcess = Start-Process -FilePath $hilNode -ArgumentList @($hilEntry,'probe','HIL',$hilProbe) -WorkingDirectory $hilRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $hilControl 'probe.stdout.log') -RedirectStandardError (Join-Path $hilControl 'probe.stderr.log') -Wait -PassThru
  @{ exitCode=$hilProcess.ExitCode; finishedUtc=(Get-Date).ToUniversalTime().ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $hilControl 'probe-exit.json') -Encoding UTF8
  if ($hilProcess.ExitCode -ne 0) { throw "HIL probe exited $($hilProcess.ExitCode); campaign not launched." }
  $hilReceipt = Join-Path $hilProbe 'probe.json'
  $hilQualification = Get-Content -LiteralPath $hilReceipt -Raw | ConvertFrom-Json
  if ($null -eq $hilQualification.recommendedConcurrency -or $hilQualification.recommendedConcurrency -lt 1) { throw 'No qualified HIL concurrency; campaign not launched.' }
  @{ phase='campaign'; startedUtc=(Get-Date).ToUniversalTime().ToString('o'); wrapperPid=$PID; concurrency=$hilQualification.recommendedConcurrency } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $hilControl 'state.json') -Encoding UTF8
  $hilProcess = Start-Process -FilePath $hilNode -ArgumentList @($hilEntry,'launch','HIL',$hilCampaign,$hilReceipt) -WorkingDirectory $hilRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $hilControl 'campaign.stdout.log') -RedirectStandardError (Join-Path $hilControl 'campaign.stderr.log') -Wait -PassThru
  @{ exitCode=$hilProcess.ExitCode; finishedUtc=(Get-Date).ToUniversalTime().ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $hilControl 'campaign-exit.json') -Encoding UTF8
  @{ phase='finished'; exitCode=$hilProcess.ExitCode; finishedUtc=(Get-Date).ToUniversalTime().ToString('o'); wrapperPid=$PID } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $hilControl 'state.json') -Encoding UTF8
  exit $hilProcess.ExitCode
} catch {
  $_ | Out-String | Set-Content -LiteralPath (Join-Path $hilControl 'wrapper-error.log') -Encoding UTF8
  @{ phase='failed'; message=$_.Exception.Message; finishedUtc=(Get-Date).ToUniversalTime().ToString('o'); wrapperPid=$PID } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $hilControl 'state.json') -Encoding UTF8
  exit 1
}
