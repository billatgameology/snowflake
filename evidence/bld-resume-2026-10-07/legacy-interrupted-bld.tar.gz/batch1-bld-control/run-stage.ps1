param([Parameter(Mandatory=$true)][ValidateSet('probe','launch')][string]$Mode)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'G:/Code Files/snowflake-bld-exploration'
$stageDirectory = 'G:/Code Files/snowflake-bld-exploration/out/batch1-bld-control'
$nodeExecutable = (Get-Command node.exe).Source
$stageArguments = @('runner/src/hil-bld-batch-main.ts', $Mode, 'BLD')
if ($Mode -eq 'probe') { $stageArguments += 'out/batch1-bld-probe' }
else { $stageArguments += @('out/batch1-bld', 'out/batch1-bld-probe/probe.json') }
$stageStartedUtc = (Get-Date).ToUniversalTime().ToString('o')
$stageHead = (git rev-parse HEAD).Trim()
$stageExitCode = 1
$stageFailure = $null
try {
  & $nodeExecutable @stageArguments
  $stageExitCode = $LASTEXITCODE
} catch {
  $stageFailure = $_.Exception.Message
  [Console]::Error.WriteLine($stageFailure)
} finally {
  [pscustomobject]@{ mode=$Mode; gitHead=$stageHead; exactCommand=@($nodeExecutable)+$stageArguments;
    startedUtc=$stageStartedUtc; finishedUtc=(Get-Date).ToUniversalTime().ToString('o');
    exitCode=$stageExitCode; error=$stageFailure } | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $stageDirectory ($Mode + '.exit.json')) -Encoding utf8
}
if ($Mode -eq 'launch' -and (Test-Path -LiteralPath 'out/batch1-bld/campaign.json')) {
  $summaryStartedUtc = (Get-Date).ToUniversalTime().ToString('o')
  $summaryExitCode = 1
  $summaryFailure = $null
  $summaryArguments = @('runner/src/hil-bld-batch-main.ts', 'summarize', 'out/batch1-bld')
  try {
    $summaryProcess = Start-Process -FilePath $nodeExecutable -ArgumentList $summaryArguments -WorkingDirectory 'G:/Code Files/snowflake-bld-exploration' -WindowStyle Hidden -RedirectStandardOutput (Join-Path $stageDirectory 'campaign-summary.json') -RedirectStandardError (Join-Path $stageDirectory 'campaign-summary.stderr.log') -Wait -PassThru
    $summaryExitCode = $summaryProcess.ExitCode
  } catch {
    $summaryFailure = $_.Exception.Message
  } finally {
    [pscustomobject]@{ exactCommand=@($nodeExecutable)+$summaryArguments; startedUtc=$summaryStartedUtc;
      finishedUtc=(Get-Date).ToUniversalTime().ToString('o'); exitCode=$summaryExitCode; error=$summaryFailure } |
      ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stageDirectory 'campaign-summary.exit.json') -Encoding utf8
  }
}
exit $stageExitCode

